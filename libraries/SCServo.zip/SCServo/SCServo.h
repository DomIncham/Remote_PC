/*
 * SCServo.h
 * interface for waveshare serial bus servo
 * date: 2023.6.11 
 */

#ifndef _SCSERVO_H
#define _SCSERVO_H

#include "SCSCL.h"
#include "SMS_STS.h"

#endif