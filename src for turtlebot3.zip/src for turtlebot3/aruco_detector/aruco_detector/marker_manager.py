import os
import csv
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.duration import Duration
from rclpy.executors import MultiThreadedExecutor

from geometry_msgs.msg import Point, PoseWithCovarianceStamped, PoseStamped
from visualization_msgs.msg import Marker
import sys  # เพิ่มไว้บนสุด
import select


class MarkerManager(Node):
    def __init__(self):
        super().__init__('marker_manager')

        # Path Storage
        self.tb3_path = []
        self.aruco_path = []
        self.expected_path = [
            Point(x=-0.6, y=0.0, z=0.0),
            Point(x=1.0, y=0.0, z=0.0),
            Point(x=1.0, y=-3.0, z=0.0),
            Point(x=4.5, y=-3.0, z=0.0),
        ]

        # Publishers
        self.tb3_marker_pub = self.create_publisher(Marker, '/turtlebot3_path_marker', 10)
        self.aruco_marker_pub = self.create_publisher(Marker, '/aruco_path_marker', 10)
        self.expected_path_pub = self.create_publisher(Marker, '/expected_path_marker', 10)

        # Subscribers
        self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', self.amcl_callback, 10)
        self.create_subscription(PoseStamped, '/aruco_marker_pose', self.aruco_callback, 10)

        # Timers
        self.create_timer(0.5, self.publish_tb3_path_marker)
        self.create_timer(0.5, self.publish_aruco_path_marker)
        self.create_timer(1.0, self.publish_expected_path_marker)

        # Logging + Export
        self.log_dir = '/workspaces/ros2-workspace/Path_log'
        os.makedirs(self.log_dir, exist_ok=True)

    def amcl_callback(self, msg):
        p = msg.pose.pose.position
        self.tb3_path.append(Point(x=p.x, y=p.y, z=p.z))

    def aruco_callback(self, msg):
        p = msg.pose.position
        self.aruco_path.append(Point(x=p.x, y=p.y, z=p.z))

    def publish_tb3_path_marker(self):
        marker = Marker()
        marker.header.frame_id = "map"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "tb3_path"
        marker.id = 1
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.points = self.tb3_path
        marker.scale.x = 0.02
        marker.color.r = 0.0
        marker.color.g = 0.6
        marker.color.b = 1.0
        marker.color.a = 1.0
        self.tb3_marker_pub.publish(marker)

    def publish_aruco_path_marker(self):
        marker = Marker()
        marker.header.frame_id = "map"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "aruco_path"
        marker.id = 2
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.points = self.aruco_path
        marker.scale.x = 0.02
        marker.color.r = 0.0
        marker.color.g = 1.0
        marker.color.b = 0.5
        marker.color.a = 1.0
        self.aruco_marker_pub.publish(marker)

    def publish_expected_path_marker(self):
        marker = Marker()
        marker.header.frame_id = "map"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "expected_path"
        marker.id = 3
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.points = self.expected_path
        marker.scale.x = 0.03
        marker.color.r = 1.0
        marker.color.g = 1.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        self.expected_path_pub.publish(marker)

    def export_to_csv(self):
        timestamp = self.get_clock().now().to_msg().sec
        filename = f'{self.log_dir}/path_log_{timestamp}.csv'
        max_len = max(len(self.expected_path), len(self.aruco_path), len(self.tb3_path))
        with open(filename, mode='w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'expected_x', 'expected_y', 'expected_z',
                'aruco_x', 'aruco_y', 'aruco_z',
                'tb3_x', 'tb3_y', 'tb3_z'
            ])
            for i in range(max_len):
                row = []
                for lst in [self.expected_path, self.aruco_path, self.tb3_path]:
                    if i < len(lst):
                        row.extend([lst[i].x, lst[i].y, lst[i].z])
                    else:
                        row.extend(['', '', ''])
                writer.writerow(row)
        self.get_logger().info(f"✅ CSV saved: {filename}")


def main(args=None):
    rclpy.init(args=args)
    node = MarkerManager()
    executor = MultiThreadedExecutor()
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        node.export_to_csv()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

