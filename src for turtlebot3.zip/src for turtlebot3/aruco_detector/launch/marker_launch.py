from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='aruco_detector',
            executable='marker_manager',
            name='marker_manager_node',
            parameters=[{'use_sim_time': True}],
            output='screen'
        )
    ])
